export { KTToggle } from './toggle';
export type { KTToggleConfigInterface, KTToggleInterface } from './types';
