export { KTAccordion } from './accordion';
export type { KTAccordionConfigInterface, KTAccordionInterface } from './types';
