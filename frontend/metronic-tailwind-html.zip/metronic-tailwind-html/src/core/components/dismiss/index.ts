export { KTDismiss } from './dismiss';
export type { KTDismissConfigInterface, KTDismissInterface } from './types';
