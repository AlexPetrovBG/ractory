export { KTSticky } from './sticky';
export type { KTStickyConfigInterface, KTStickyInterface } from './types';
