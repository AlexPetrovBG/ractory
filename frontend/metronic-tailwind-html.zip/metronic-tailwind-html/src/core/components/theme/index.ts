export { KTTheme } from './theme';
export type { KTThemeConfigInterface, KTThemeInterface } from './types';
