export { KTScrollable } from './scrollable';
export type { KTScrollableConfigInterface, KTScrollableInterface } from './types';
