export { KTModal } from './modal';
export type { KTModalConfigInterface, KTModalInterface } from './types';
