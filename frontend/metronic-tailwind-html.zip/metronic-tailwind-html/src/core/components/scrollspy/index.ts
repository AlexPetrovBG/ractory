export { KTScrollspy } from './scrollspy';
export type { KTScrollspyConfigInterface, KTScrollspyInterface } from './types';
