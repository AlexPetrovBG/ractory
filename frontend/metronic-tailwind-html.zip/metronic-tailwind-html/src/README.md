## Metronic 9 Tailwind HTML

### Raw HTML Code
- To work with raw HTML templates for each demo, navigate to the `dist/html` folder.

### Dynamic HTML Code
- Streamline your Metronic projects with our HTML file-based mini CMS tool, [Metronic Composer](https://keenthemes.com/metronic/tailwind/docs/composer), 
designed to save you time and effort.

